# Build a Prime Number Checker Module

```json
{ "tags": ["Certification Project"] }
```

For this project, you will build a prime number checker as an NPM module.

## 0

### --description--

In this project, you will apply what you learned about building npm modules to create a `prime-checker` module from scratch. Work within the `build-a-prime-number-checker-module/` directory.

A <dfn title="prime number">prime number</dfn> is a whole number greater than 1 that has no divisors other than 1 and itself (e.g. 2, 3, 5, 7, 11).

Within an `index.js`, write a function named `isPrime` that takes a number as an argument and returns `true` if it is prime, or `false` otherwise. Then export `isPrime` as a named property of `module.exports`.

**Objective:** Fulfill the user stories below and get all the tests to pass to complete the lab.

**User Stories:**

1. You should have an `index.js` file.

2. The project directory should be an npm package. Its `package.json` should have `name`, `version`, `description`, `keywords`, `license`, and `author` properties (all strings, with `keywords` an array), and a `type` property set to `commonjs`.

3. Your `index.js` file should define a function named `isPrime`.

4. Your `isPrime` function should be exported as a named property of `module.exports`.

5. Calling `isPrime` with a prime number should return `true`.

6. Calling `isPrime` with a non-prime number should return `false`.

### --tests--

You should have an `index.js` file.

```js
const __exists = await __helpers.fileExists(project.dashedName, "index.js");
assert.isTrue(__exists, "index.js should exist");
```

The project directory should be an npm package.

```js
const f = await __helpers.getFile(project.dashedName, "package.json");
assert.isString(f, "package.json should exist");
const p = JSON.parse(f);
assert.property(p, "name");
assert.property(p, "version");
assert.property(p, "description");
assert.property(p, "keywords");
assert.property(p, "license");
assert.property(p, "author");
assert.property(p, "type");

assert.isString(p.name, "the package name should be a string");
assert.isString(p.version, "the package version should be a string");
assert.isString(p.description, "the package description should be a string");
assert.isArray(p.keywords, "the package keywords should be an array");
assert.isString(p.license, "the package license should be a string");
assert.isString(p.author, "the package author should be a string");
assert.equal(p.type, "commonjs", "the package type should be commonjs");
```

Your `index.js` file should define a function named `isPrime`.

```js
const __file = await __helpers.getFile(project.dashedName, "index.js");
const __t = new __helpers.Tower(__file);
const __fn = __t.getFunction("isPrime");
assert.isDefined(__fn, "index.js should define a function named isPrime");
```

Your `isPrime` function should be exported as a named property of `module.exports`.

```js
const __file = await __helpers.getFile(project.dashedName, "index.js");
const __babelised = new __helpers.Babeliser(__file);
const __exportStatement = __babelised.getExpressionStatements().find((e) => {
  const left = e.expression?.left;
  return (
    (left?.object?.name === "module" && left?.property?.name === "exports") ||
    (left?.object?.object?.name === "module" &&
      left?.object?.property?.name === "exports")
  );
});
assert.exists(
  __exportStatement,
  "index.js should use module.exports to export",
);
const __mod = await __helpers.importSansCache(`${project.dashedName}/index.js`);
const __isPrime = __mod.isPrime ?? __mod.default?.isPrime;
assert.isFunction(
  __isPrime,
  "isPrime should be exported as a named property of `module.exports`",
);
```

Calling `isPrime` with a prime number should return `true`.

```js
const __mod = await __helpers.importSansCache(`${project.dashedName}/index.js`);
const __isPrime = __mod.isPrime ?? __mod.default?.isPrime;
assert.isFunction(
  __isPrime,
  "isPrime should be exported as a named property of `module.exports`",
);
for (const n of [2, 3, 5, 11, 97]) {
  assert.strictEqual(__isPrime(n), true, `isPrime(${n}) should return true`);
}
```

Calling `isPrime` with a non-prime number should return `false`.

```js
const __mod = await __helpers.importSansCache(`${project.dashedName}/index.js`);
const __isPrime = __mod.isPrime ?? __mod.default?.isPrime;
assert.isFunction(
  __isPrime,
  "isPrime should be exported as a named property of `module.exports`",
);
for (const n of [1, 4, 9, 15, 100]) {
  assert.strictEqual(__isPrime(n), false, `isPrime(${n}) should return false`);
}
```

## --fcc-end--
